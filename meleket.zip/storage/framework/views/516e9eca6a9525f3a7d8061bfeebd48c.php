<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('about.partials.mission-vision', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('about.partials.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\meleket\resources\views/about/index.blade.php ENDPATH**/ ?>