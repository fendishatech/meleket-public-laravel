<section class="px-6">
    <h1 class="py-6 my-6 text-center text-4xl text-black font-bold">Our Misssion and Vision</h1>
    <div class="flex gap-4">
        <div class="flex-1">
            <h1 class="my-4 text-4xl">Mission</h1>
            <p> To prepare individual learners for success in life by taking learners’ multiple intelligences into
                account and
                providing quality and meaningful learning experience in safe and caring environment.
            </p>
        </div>
        <div class="flex-1">
            <h1 class="my-4 text-4xl">Vision</h1>
            <p> Achieving inclusive educational excellence
            </p>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\meleket\resources\views/about/partials/mission-vision.blade.php ENDPATH**/ ?>