<section class="px-6 h-[500px] flex items-center justify-center hero-bg">
    <h1 class="text-center text-3xl md:text-5xl  font-bold">Every Child is intelligent!</h1>
</section>
